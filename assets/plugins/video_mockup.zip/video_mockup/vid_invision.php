<?php 
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
/**
 * 
 * 
 */
/*
Plugin Name: Video MockUp
Plugin URI: 
Description: for Video Mockup App
Author: Vid Team
Version: 1.0
Author URI:
*/

function loadExternalJS()
{
	wp_enqueue_script( 'externalJS', plugin_dir_url( __FILE__ ) . 'external.js', array('jquery'), '', true );	
}
function loadExternalAutoJS()
{
	wp_enqueue_script( 'externalautoJS', plugin_dir_url( __FILE__ ) . 'external_auto.js', array('jquery'), '', true );	
}

add_action('wp_enqueue_scripts','loadExternalJS');
add_action('wp_enqueue_scripts','loadExternalAutoJS');

function vidVisionShortcode($attr)
{
	//echo "<pre>";	
	//print_r($attr);
	//echo "</pre>";	
	
	$outputCode = '';
	
	if(isset($attr['vid']) && $attr['mocuk_position'] !='none' && $attr['mocuk_position'] !="" )
	{
	echo "<div align='".$attr['mocuk_position']."'>";
	}

	$outputCode .='<div class="ivf_container" style="width:'.$attr["width"].'px;height:'.$attr["height"].'px" id="campaign-'.$attr["cid"].'">';
	$outputCode .='<div class="i_video_player '.$attr["mockup"].'">';
	$outputCode .='<img class="ivf_frame" src="'.$attr["mockup_url"].'">';	  
	
	if($attr['autoplay'] ==0)
	{
		$outputCode .='<div class="player_wrapper '.$attr["mockup"].'" style="background: url('.$attr["landing_img"].') no-repeat center center; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">';
		$outputCode .='<i class="play_shadow play_animation play_btn play_large admin iPlayBtnID '.$attr["play_icon"].'" style="color:#ffffff"  data-video_url="'.$attr["video_url"].'"></i>';
	}
	else
	{
		$outputCode .='<div class="player_wrapper '.$attr["mockup"].'">';
		$outputCode .='<i class="play_shadow iPlayBtnID" style="color:#ffffff"  data-video_url="'.$attr["video_url"].'"></i>';
	}

	
	if(isset($attr["action_redirect_url"]) && $attr["action_redirect_url"] !='')
	{
		if($getCidData['width'] <=400 )
		{
			$actionClass = "action-btn-width-400";
		}
		elseif($getCidData['width'] > 400 && $getCidData['width'] <=500)
		{
			$actionClass = "action-btn-width-500";
		}
		elseif($getCidData['width'] > 500 && $getCidData['width'] <=600)
		{
			$actionClass = "action-btn-width-600";
		}
		elseif($getCidData['width'] > 600 && $getCidData['width'] <=700)
		{
			$actionClass = "action-btn-width-700";
		}
		elseif($getCidData['width'] > 700 && $getCidData['width'] <=800)
		{
			$actionClass = "action-btn-width-700";
		}
		elseif($getCidData['width'] > 800 && $getCidData['width'] <=900)
		{
			$actionClass = "action-btn-width-800";
		}
		elseif($getCidData['width'] > 900 && $getCidData['width'] <=1000)
		{
			$actionClass = "action-btn-width-900";
		}
	
		$outputCode .='<div class="button-styling '.$actionClass.'">';
		$outputCode .='<div class="btnClose">X</div>';
		$outputCode .='<div style="background:'.$attr["btn_container_bg"].';" class="btnFinalBackground" data-btn-delay="'.$attr["action_delay"].'">';
		$outputCode .='<div class="btnFinalTitle" style="color:'.$attr["btn_title_color"].'">'.$attr["action_hover_title"].' </div>';
		$outputCode .='<div class="btn btn-fill btn-info button-text-custom call-to-action-btn btnFinal button-text-custom '.$attr['btn_bg'].'">';
		$outputCode .='<a style="color: '.$attr["btn_txt_color"].';" href="'.$attr["action_redirect_url"].'">'.$attr["action_btn_txt"].' </a>';
		$outputCode .='</div>';
		$outputCode .='</div>';
		$outputCode .='</div>';
	}
	
	
	if(isset($attr["banner_redirect_url"]) && $attr["banner_redirect_url"] != '')
	{
		$outputCode .='<div class="bannerPreview" data-banner-delay="'.$attr["banner_delay"].'">';
		$outputCode .='<div class="bannerClose">X</div>';
		$outputCode .='<a href="'.$attr["banner_redirect_url"].'">';
		$outputCode .='<img src="'.$attr["banner_url"].'">';
		$outputCode .='</a>';
		$outputCode .='</div>';	
	}
	
	if(isset($attr["buynow_url"]) && $attr["buynow_url"] != '')
	{
		$outputCode .='<div class="buyNowPreview" data-buynow-delay="'.$attr["buynow_delay"].'">';
		$outputCode .='<div class="buyNowClose">X</div>';
		$outputCode .='<a href="'.$attr["buynow_url"].'">';
		$outputCode .='<img src="'.$attr["buynow_btn"].'"> ';
		$outputCode .='</a>';
		$outputCode .='</div>';
	}
	
	
	
	if((isset($attr['lead_responder']) && $attr['lead_responder'] !=''))
	{

		$outputCode .='<div id="optinforms-form3" data-lead-delay = "50">';
		$outputCode .='<div class="leadClose">X</div>';
		$outputCode .='<div id="optinforms-form3-inside">';
		$outputCode .='<div class="optinforms-form3-container-left" id="image-preview" style="background-image: url('.$attr["lead_image"].';)">';
		$outputCode .='</div>';
		$outputCode .='<div id="optinforms-form3-container-right">';
		$outputCode .='<div class="utm_title_container">';
		$outputCode .='<h2 class="vid_inv_form_title">'.$attr["lead_title"].'</h2>';
		$outputCode .='<h4 class="vid_inv_form_desc">'.$attr["lead_desc"].'</h4>';
		$outputCode .='</div>';
			
			if(!empty($attr['lead_responder']) && $attr['lead_responder'] == 'AWeber')
				$formAction = 'http://www.aweber.com/scripts/addlead.pl';
			else if(!empty($attr['lead_responder']) && $attr['lead_responder'] == 'GetResponse')
				$formAction = 'https://app.getresponse.com/add_contact_webform.html';
			else if(!empty($attr['lead_responder']) && $attr['lead_responder'] == 'Mailchimp')
				$formAction = $attr['form_action'];
			else
				$formAction = '';
			
			
			$outputCode .='<form action="'.$formAction.'" method="post" id="leadFrm">';
			$outputCode .='<input type="text" placeholder="Your Name" name="name" class="optinforms-form3-name-field">';
			$outputCode .='<input type="text" placeholder="Your Email Address" name="email" class="optinforms-form3-name-field">';
			
			if(!empty($attr['lead_responder']) && $attr['lead_responder'] == 'AWeber')
			{
				$outputCode .='<input type="hidden" name="listname" value="'.$attr['lead_id'].'" />';
				$outputCode .= '<input type="hidden" name="redirect" value="'.$attr['lead_url'].'" />';
			}
			elseif(!empty($attr['lead_responder']) && $attr['lead_responder'] == 'Mailchimp')
			{
				$outputCode .= '<input type="text" placeholder="First Name" name="FNAME" class="optinforms-form3-name-field">';
				$outputCode .= '<input type="text" placeholder="Your Email Address" name="EMAIL" class="optinforms-form3-name-field">';
			}
			else
			{ 
				$outputCode .= '<input type="hidden" name="webform_id" value="'.$attr['lead_id'].'" />';
			}
			$outputCode .= '<button type="button" class="vid_inv_form_btn leadBtn" id="optinforms-form3-button">'.$attr['lead_button'].'</button>';
			$outputCode .= '</form>';
			$outputCode .= '</div>';
			$outputCode .= '<div class="clear"></div>';
			$outputCode .= '</div>';
			$outputCode .= '</div>';

	}
	
	$outputCode .='</div>';
	$outputCode .='</div>';
	$outputCode .='</div>';
	
	if(isset($attr['vid']) && $attr['mocuk_position'] !='none' && $attr['mocuk_position'] !="" )
	{
		$outputCode .='</div>';
	}
	
	
	echo $outputCode;

}

add_shortcode("vidvision", "vidVisionShortcode");

?>